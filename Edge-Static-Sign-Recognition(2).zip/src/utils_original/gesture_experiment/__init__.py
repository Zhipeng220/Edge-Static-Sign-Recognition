"""Modular gesture experiment package."""
